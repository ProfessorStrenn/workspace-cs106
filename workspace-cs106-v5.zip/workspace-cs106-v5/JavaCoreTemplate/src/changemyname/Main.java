package changemyname;

import static sbcc.Core.*;

import java.util.*;

import static java.lang.System.*;
import static org.apache.commons.lang3.StringUtils.*;
import static java.util.Arrays.*;

/**
 * 
 * @author your_name_here
 *
 */
public class Main {

	public static void main(String[] args) {
	}

}
